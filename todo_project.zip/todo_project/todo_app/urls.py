from django.urls import path
from .views import TaskCreateView, TaskUpdateView, TaskDeleteView, TaskListView, EmployeeCreateView, EmployeeDeleteView, EmployeeUpdateView, EmployeeListView, EmployeeTaskListView, EmployeeTaskUpdateView

urlpatterns = [
    path('task/add/', TaskCreateView.as_view(), name='admin_add_task'),
    path('task/<int:pk>/edit/', TaskUpdateView.as_view(), name='admin_edit_task'),
    path('task/<int:pk>/delete/', TaskDeleteView.as_view(), name='admin_delete_task'),
    path('tasks/', TaskListView.as_view(), name='admin_view_tasks'),
    path('employee/add/', EmployeeCreateView.as_view(), name='admin_add_employee'),
    path('employee/<int:pk>/delete/', EmployeeDeleteView.as_view(), name='admin_delete_employee'),
    path('employee/<int:pk>/edit/', EmployeeUpdateView.as_view(), name='admin_edit_employee'),
    path('employees/', EmployeeListView.as_view(), name='admin_view_employees'),
    path('employee/tasks/', EmployeeTaskListView.as_view(), name='employee_view_tasks'),
    path('employee/task/<int:pk>/edit/', EmployeeTaskUpdateView.as_view(), name='employee_edit_task'),
]
