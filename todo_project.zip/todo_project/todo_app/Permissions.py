
# permissions.py

from django.contrib.auth.mixins import UserPassesTestMixin
from django.core.exceptions import PermissionDenied
from .models import CustomUser, Task

class EmployerPermission(UserPassesTestMixin):
    def test_func(self):
        user = self.request.user
        if user.is_authenticated and user.role == 'employer':
            return True
        raise PermissionDenied("You do not have permission to access this page.")

class EmployeePermission(UserPassesTestMixin):
    def test_func(self):
        user = self.request.user
        if user.is_authenticated and user.role == 'employee':
            return True
        raise PermissionDenied("You do not have permission to access this page.")






























