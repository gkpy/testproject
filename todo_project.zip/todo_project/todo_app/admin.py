

# Register your models here.
from django.contrib import admin
from .models import Task, CustomUser

admin.site.register(Task)
admin.site.register(CustomUser)
















"""from django.contrib import admin
from .models import User, Employer, Employee, Task

admin.site.register(User)
admin.site.register(Employer)
admin.site.register(Employee)
admin.site.register(Task)"""