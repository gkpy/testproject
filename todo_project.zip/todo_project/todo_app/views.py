
# views.py

from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib import messages
from django.views.generic import ListView, CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from .models import Task, CustomUser
from .forms import TaskForm
from .Permissions import EmployerPermission, EmployeePermission
from rest_framework.authtoken.views import obtain_auth_token
from rest_framework.decorators import api_view

# View for adding a task by employer
class TaskCreateView(LoginRequiredMixin, EmployerPermission, CreateView):
    model = Task
    form_class = TaskForm
    template_name = 'admin_add_task.html'
    success_url = reverse_lazy('admin_view_tasks')

    def form_valid(self, form):
        form.instance.employer = self.request.user
        return super().form_valid(form)

# View for editing a task by employer
class TaskUpdateView(LoginRequiredMixin, EmployerPermission, UpdateView):
    model = Task
    form_class = TaskForm
    template_name = 'admin_edit_task.html'
    success_url = reverse_lazy('admin_view_tasks')

# View for deleting a task by employer
class TaskDeleteView(LoginRequiredMixin, EmployerPermission, DeleteView):
    model = Task
    template_name = 'admin_confirm_delete.html'
    success_url = reverse_lazy('admin_view_tasks')

# View for viewing all tasks by employer
class TaskListView(LoginRequiredMixin, EmployerPermission, ListView):
    model = Task
    template_name = 'admin_view_tasks.html'
    context_object_name = 'tasks'

# View for adding an employee by employer
class EmployeeCreateView(LoginRequiredMixin, EmployerPermission, CreateView):
    model = CustomUser
    template_name = 'admin_add_employee.html'
    fields = ['phone_number', 'password']
    success_url = reverse_lazy('admin_view_employees')

    def form_valid(self, form):
        form.instance.role = 'employee'
        return super().form_valid(form)

# View for deleting an employee by employer
class EmployeeDeleteView(LoginRequiredMixin, EmployerPermission, DeleteView):
    model = CustomUser
    template_name = 'admin_confirm_delete.html'
    success_url = reverse_lazy('admin_view_employees')

# View for editing an employee by employer
class EmployeeUpdateView(LoginRequiredMixin, EmployerPermission, UpdateView):
    model = CustomUser
    template_name = 'admin_edit_employee.html'
    fields = ['phone_number', 'password']
    success_url = reverse_lazy('admin_view_employees')

# View for viewing all employees by employer
class EmployeeListView(LoginRequiredMixin, EmployerPermission, ListView):
    model = CustomUser
    template_name = 'admin_view_employees.html'
    context_object_name = 'employees'

# View for viewing all tasks by employee
class EmployeeTaskListView(LoginRequiredMixin, EmployeePermission, ListView):
    model = Task
    template_name = 'employee_view_tasks.html'
    context_object_name = 'tasks'

# View for updating the status of a task by employee
class EmployeeTaskUpdateView(LoginRequiredMixin, EmployeePermission, UpdateView):
    model = Task
    template_name = 'employee_edit_task.html'
    fields = ['status']
    success_url = reverse_lazy('employee_view_tasks')

@api_view(['POST'])
def get_auth_token(request):
    """
    Custom view to obtain authentication token using the obtain_auth_token view.
    """
    if request.method == 'POST':
        form = TaskForm(request.POST)
        if form.is_valid():
            # Perform form processing logic here
            # ...
            return obtain_auth_token(request)
    else:
        form = TaskForm()
    return render(request, 'my_template.html', {'form': form})



